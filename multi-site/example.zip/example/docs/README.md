---
title: Overview
---

# Multiple sites

Download example as archive:

[Download .zip][Download]{ .md-button .md-button--primary }

Unzip archive, change to the folder and enter:

``` bash
pip install -r requirements.txt
mkdocs serve
```

  [Download]: example.zip
