---
title: Overview
---

# Multiple sites

Note: you need to have access to Insiders for this demo.

Download example as archive:

[Download .zip][Download]{ .md-button .md-button--primary }

Unzip archive, change to the folder and enter:

``` bash
GH_TOKEN="your-github.token"
pip install -r requirements.txt
mkdocs serve
```

  [Download]: example.zip
