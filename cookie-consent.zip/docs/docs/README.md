---
title: Overview
---

# Adding a cookie consent 

This example shows how to add a [cookie consent]. [Click here] to bring
up the cookie consent again.

  [cookie consent]: https://squidfunk.github.io/mkdocs-material/setup/ensuring-data-privacy/#cookie-consent
  [Click here]: #__consent
