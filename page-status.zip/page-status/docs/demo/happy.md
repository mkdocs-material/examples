---
title: Happy
status: happy
---

# Page with happy content

This page has a custom page status.
