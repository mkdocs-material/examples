# Using custom colors

This example shows how to set [custom colors] with [additional CSS].

  [custom colors]: https://squidfunk.github.io/mkdocs-material/setup/changing-the-colors/#custom-colors
  [additional CSS]: https://squidfunk.github.io/mkdocs-material/customization/#additional-css
