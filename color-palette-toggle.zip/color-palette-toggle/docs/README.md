# Using the color palette toggle

This example shows how to implement the [color palette toggle] to let users switch
between light and dark mode. Click on the button left to the search bar to
switch between modes.

  [color palette toggle]: https://squidfunk.github.io/mkdocs-material/setup/changing-the-colors/#color-palette-toggle
