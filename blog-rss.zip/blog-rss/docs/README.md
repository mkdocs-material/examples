# Adding an RSS feed to a blog

This example shows how to [add an RSS feed to a blog]. You should be
able to point any RSS reader at the site and it will pick up the RSS
feed from a declaration in the HTML header.

  [add an RSS feed to a blog]: https://squidfunk.github.io/mkdocs-material/setup/setting-up-a-blog/?h=#rss

