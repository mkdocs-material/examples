---
status: happy
---

# Happy, happy page!

This page has a custom page status.
